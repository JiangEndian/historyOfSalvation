// ==UserScript==
// @name         dealWithBiblehubLocalization
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://localhost:3927/static/verses/* 
// @icon         https://www.google.com/s2/favicons?domain=0.1
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.getElementById('fx5').remove();//我的天呐，完全一样的两串字符，一个就楞是说没有这个函数。。。照样复制的。唉。然后把空格删除了，嘿，难道，是前面加了空格？这不可能啊。没加分号？算了。能用就行。唉。。。
    document.getElementById('l1').remove();
    document.getElementById('bot').remove();
    for(var one in document.getElementsByClassName('tb3')){
        one.remove(); //天呐，发现个好玩的：getElement的id，还有getElements的className...
    } //这个找到的是0个，不知道为什么。但，现在大块的妨碍已经没有了。可以正常使用了。而且这个会把后面的代码给卡住，这个有错，但，算了，已经能用了。为了学希伯来语，结果净折腾工具了。。。

    //alert('hi');
    //console.log(toBeDel)
    // Your code here...
})();