// ==UserScript==
// @name         dealHebrewGreek
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://localhost:3927/static/originalLang/*
// @icon         https://www.google.com/s2/favicons?domain=undefined.localhost
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.getElementById('fx2').remove();
    document.getElementById('fx3').remove();
    document.getElementById('fx5').remove();
    document.getElementById('anc').remove();
    document.getElementById('anc2').remove();
    // Your code here...
})();